import {
  collection, doc, addDoc, updateDoc, deleteDoc,
  query, orderBy, onSnapshot, serverTimestamp, Timestamp,
} from 'firebase/firestore';
import { db } from './firebase';
import { AnyItem, AreaKey, HistoryAction, UserId } from '../constants/types';

// ── History writer ────────────────────────────────────

export async function writeHistory(params: {
  area: AreaKey;
  itemId: string;
  itemTitle: string;
  action: HistoryAction;
  performedBy: UserId | 'system';
  changes?: Record<string, { before: unknown; after: unknown }>;
}): Promise<void> {
  await addDoc(collection(db, 'history'), {
    ...params,
    timestamp: serverTimestamp(),
  });
}

// ── Generic area CRUD ─────────────────────────────────

export function subscribeToArea<T extends AnyItem>(
  area: AreaKey,
  orderField: string,
  onData: (items: T[]) => void,
  orderDir: 'asc' | 'desc' = 'asc',
) {
  const q = query(collection(db, area), orderBy(orderField, orderDir));
  return onSnapshot(q, (snap) => {
    onData(snap.docs.map((d) => ({ id: d.id, ...d.data() } as T)));
  });
}

export async function createEntry<T extends Partial<AnyItem>>(
  area: AreaKey,
  data: Omit<T, 'id' | 'createdAt' | 'updatedAt'>,
  performedBy: UserId,
  titleField = 'title',
): Promise<string> {
  const ref = await addDoc(collection(db, area), {
    ...data,
    area,
    createdBy: performedBy,
    updatedBy: performedBy,
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  await writeHistory({
    area,
    itemId: ref.id,
    itemTitle: String((data as Record<string, unknown>)[titleField] ?? ''),
    action: 'created',
    performedBy,
  });
  return ref.id;
}

export async function updateEntry(
  area: AreaKey,
  id: string,
  title: string,
  changes: Record<string, unknown>,
  performedBy: UserId,
  action: HistoryAction = 'edited',
): Promise<void> {
  await updateDoc(doc(db, area, id), {
    ...changes,
    updatedBy: performedBy,
    updatedAt: serverTimestamp(),
  });
  await writeHistory({ area, itemId: id, itemTitle: title, action, performedBy });
}

export async function deleteEntry(
  area: AreaKey,
  id: string,
  title: string,
  performedBy: UserId,
): Promise<void> {
  await writeHistory({ area, itemId: id, itemTitle: title, action: 'deleted', performedBy });
  await deleteDoc(doc(db, area, id));
}

// ── History listener ──────────────────────────────────

import { HistoryEntry } from '../constants/types';

export function subscribeToHistory(
  onData: (entries: HistoryEntry[]) => void,
  filterUser?: UserId,
  filterArea?: AreaKey,
) {
  const q = query(collection(db, 'history'), orderBy('timestamp', 'desc'));
  return onSnapshot(q, (snap) => {
    let entries = snap.docs.map((d) => ({ id: d.id, ...d.data() } as HistoryEntry));
    if (filterUser) entries = entries.filter((e) => e.performedBy === filterUser);
    if (filterArea) entries = entries.filter((e) => e.area === filterArea);
    onData(entries);
  });
}
